const express=require('express');
const mysql=require('mysql');
const port=2000;
const app=express();


const db=mysql.createConnection({
    host:'localhost',
    user:'root',
    database:'Joshua',
    password:'',
});

app.get('/pushed_list',(req,res)=>{
  const sql='select * from pushed_list';
  db.query(sql,(err,data)=>{
    if(err)return res.json(err);
    return res.json(data);
  });
});
// app.post('/pushed_list',(req,res)=>{
//   const sql='insert into pushed_list values("","Tuyubahe josue","tuyubahejosue12345@gmail.com","ESTG")';
//   db.query(sql,(err,data)=>{
//     if(err) return res.json('data inserted unsuccessfull');
//     return res.json('data inserted successfull');
//   });
// });
app.delete('/pushed_list',(req,res)=>{
  const sql='delete  from pushed_list where id=4';
  db.query(sql,(err,data)=>{
    if(err) return res.json('data delete unsuccessfull');
    return res.json('data deleted successfull');
  });
});
app.post('/pushed_list',(req,res)=>{
  const sql='insert into pushed_list values("","Tuyirate Nge","tuyirateange@gmail.com","KAGESHI"),("","elia man","elieman@gmail.com","ESTG")';
                                            
  db.query(sql,(err,data)=>{
    if(err) return res.json('data updated unsuccessfull');
    return res.json('data updated successfull');
  });
});

app.listen(port,()=>{
    console.log(`app is running on :htpp//localhost ${port}`);
});